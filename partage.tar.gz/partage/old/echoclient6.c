/*  echo / client simple
    Master Informatique 2012 -- UniversitÃ© Aix-Marseille  
    Emmanuel Godard
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAXLIGNE 64

int main(int argc, char *argv[])
{
  char * hote; /* nom d'hÃ´te du  serveur */   
  char * port; /* port TCP du serveur */   
  char ip[NI_MAXHOST]; /* adresse IPv4 en notation pointÃ©e */
  struct addrinfo *resol; /* struct pour la rÃ©solution de nom */
  int s; /* descripteur de socket */

  /* Traitement des arguments */
  if (argc!=3) {/* erreur de syntaxe */
    printf("Usage: %s hote port\n",argv[0]);
    exit(1);
  }
  hote=argv[1]; /* nom d'hÃ´te du  serveur */   
  port=argv[2]; /* port TCP du serveur */   

  /* RÃ©solution de l'hÃ´te */
  if ( getaddrinfo(hote,port,NULL, &resol) < 0 ){
    perror("rÃ©solution adresse");
    exit(2);
  }

  /* On extrait l'addresse IP */
  inet_ntop(AF_INET6, &(((struct sockaddr_in6*)resol->ai_addr)->sin6_addr), ip, INET6_ADDRSTRLEN);

  /* CrÃ©ation de la socket, de type TCP / IP */
  /* On ne considÃ¨re que la premiÃ¨re adresse renvoyÃ©e par getaddrinfo */
  if ((s=socket(resol->ai_family,resol->ai_socktype, resol->ai_protocol))<0) {
    perror("allocation de socket");
    exit(3);
  }
  fprintf(stderr,"le nÂ° de la socket est : %i\n",s);

  /* Connexion */
  fprintf(stderr,"Essai de connexion Ã  %s (%s) sur le port %s\n\n",
	  hote,ip,port);
  if (connect(s,resol->ai_addr,sizeof(struct sockaddr_in6))<0) {
    perror("connexion");
    exit(4);
  }
  freeaddrinfo(resol); /* /!\ LibÃ©ration mÃ©moire */

  /* Session */
  char tampon[MAXLIGNE + 3]; /* tampons pour les communications */
  ssize_t lu;
  int fini=0;
  while( 1 ) { 
    /* Jusqu'Ã  fermeture de la socket (ou de stdin)     */
    /* recopier Ã  l'Ã©cran ce qui est lu dans la socket  */
    /* recopier dans la socket ce qui est lu dans stdin */

    /* rÃ©ception des donnÃ©es */
    lu = recv(s,tampon,MAXLIGNE,0); /* bloquant */
    if (lu == 0 ) {
      fprintf(stderr,"Connexion terminÃ©e par l'hÃ´te distant\n");
      break; /* On sort de la boucle infinie */
    }
    tampon[lu] = '\0';
    printf("reÃ§u: %s",tampon);
    if ( fini == 1 )
      break;  /* on sort de la boucle infinie*/
    
    /* recopier dans la socket ce qui est entrÃ© au clavier */    
    if ( fgets(tampon,MAXLIGNE - 2,stdin) == NULL ){/* entrÃ©e standard fermÃ©e */
      fini=1;
      fprintf(stderr,"Connexion terminÃ©e !!\n");
      fprintf(stderr,"HÃ´te distant informÃ©...\n");
      shutdown(s, SHUT_WR); /* terminaison explicite de la socket 
			     dans le sens client -> serveur */
      /* On ne sort pas de la boucle tout de suite ... */
    }else{   /* envoi des donnÃ©es */
      send(s,tampon,strlen(tampon),0);
    }
  } 
  /* Destruction de la socket */
  close(s);

  fprintf(stderr,"Fin de la session.\n");
  return EXIT_SUCCESS;
}
