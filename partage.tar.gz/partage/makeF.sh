#!/bin/bash

gcc iftun.c -c -std=c99
gcc inter.c -o inter -std=c99
gcc extremite.c -c -std=c99
